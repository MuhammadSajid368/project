import React, { useEffect } from "react";
import { Route, Routes, useLocation } from "react-router-dom";
import "./css/style.css";
import "./charts/ChartjsConfig";
// Import pages
import { Toaster } from "react-hot-toast";
import AccountActivation from "./pages/auth/AccountActivate.jsx";
// import StudentsTable from "./Componenets/StudentsTable";
import { AuthProvider } from "./context/auth.jsx";
import Navbar from "./layout/Navbar.jsx";
import Dashboard from "./pages/Admin/Dashboard";
import Home from "./pages/Main/Home";
import SignUp from "./pages/auth/Signup.jsx";
import Login from "./pages/auth/Login.jsx";
import AccessAccount from "./pages/auth/AccessAccount.jsx";
import P404 from "./layout/P404.jsx";
import AllUsers from "./pages/Admin/AllUsers.jsx";
import SingleUser from "./pages/Admin/SingleUser.jsx";
import LeaveRequestForm from "./layout/forms/LeaveRequestForm.jsx";
import Calendar from "./layout/Calender.jsx";
import UsersRegisterForm from "./pages/auth/UsersRegisterFomr.jsx";
import ForgotPassword from "./pages/auth/ForgotPassword.jsx";
import AddCourse from "./pages/Admin/AddCourse.jsx";
import CoursesList from "./pages/Admin/AllCourses.jsx";
import AddEvents from "./pages/Admin/AddEvents.jsx";
import Update from "./pages/Admin/UpdateEvent.jsx";
import RegisterNow from "./pages/Main/RegisterNow.jsx";
import Courses from "./pages/Main/Courses.jsx";
import About from "./pages/Main/About/About.jsx";
import SingleCourse from "./pages/Admin/SingleCourse.jsx";
import AllStudents from "./pages/Admin/AllStudents.jsx";
import AllTeachers from "./pages/Admin/AllTeachers.jsx";
import AllFeaculty from "./pages/Admin/AllFeaculty.jsx";
import MaybeShow from "./components/MaybeShow.jsx";
import CourseDetails from "./pages/Main/CourseDetails.jsx";
import FeacultyDashboard from "./pages/Faculty/dashboard/FeacultyDashboard.jsx";
import StudentDashboard from "./pages/Student/dashboard/StudentDashboard.jsx";
import TeacherDashboard from "./pages/Teacher/dashboard/TeacherDashboard.jsx";
import GuestDashboard from "./pages/guest/dashboard/GuestDashboard.jsx";
import Leave from "./pages/Student/dashboard/Leave.jsx";
import CharimansMessage from "./pages/Main/About/CharimansMessage.jsx";
import RectorMessages from "./pages/Main/About/RectorMessages.jsx";
import HIstory from "./pages/Main/About/HIstory.jsx";

function App() {
  const location = useLocation();

  useEffect(() => {
    document.querySelector("html").style.scrollBehavior = "auto";
    window.scroll({ top: 0 });
    document.querySelector("html").style.scrollBehavior = "";
  }, [location.pathname]);

  return (
    <div className="m-0 p-0 top-0 ">
      <AuthProvider>
        <MaybeShow>
          <Navbar />
        </MaybeShow>
        <Toaster />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/about/chairman's-message" element={<CharimansMessage />} />
          <Route path="/about/rector's-message" element={<RectorMessages />} />
          <Route path="/about/our-history" element={<HIstory />} />
          <Route path="/register/now" element={<RegisterNow />} />
          <Route path="/courses" element={<Courses />} />
          <Route path="/course/detail/:id" element={<CourseDetails />} />

          <Route path="/add/event" element={<Calendar />} />

          {/*  Auth Routes */}
          <Route path="/create/account" element={<UsersRegisterForm />} />
          <Route path="/auth/signup" element={<SignUp />} />
          <Route path="/auth/login" element={<Login />} />
          <Route
            path="/auth/password/forgot-password"
            element={<ForgotPassword />}
          />
          <Route
            path="/auth/access-account/:token"
            element={<AccessAccount />}
          />
          <Route path="/student/request-for-leave" element={<Leave />} />
          <Route
            path="/auth/account-activate/:token"
            element={<AccountActivation />}
          />

          <Route path="/event" element={<AddEvents />} />
          <Route path="/update/:id" element={<Update />} />
          {/* <Route path="/" element={<PrivateRoutes />} > */}
          <Route exact path="admin/dashboard" element={<Dashboard />} />
          <Route exact path="/admin/courses/add" element={<AddCourse />} />
          {/* </Route> */}
          {/* Student Routes */}
          <Route exact path="/student/dashboard" element={<StudentDashboard />} />
          {/* End Student Route */}
          {/* Teacher Route */}
          <Route exact path="/teacher/dashboard" element={<TeacherDashboard />} />
          {/* End Teacher Route */}

          {/* Staff Route */}
          <Route path="/feaculty/dashboard" element={<FeacultyDashboard />} />
          {/* End Staff Route */}

          {/* Guest Route */}
          <Route path="/guest/dashboard" element={<GuestDashboard />} />
          {/* End Guest Route */}

          {/* Admin Route */}
          <Route path="/admin/all-users-data" element={<AllUsers />} />
          <Route path="/students/record" element={<AllStudents />} />
          <Route path="/professor/list" element={<AllTeachers />} />
          <Route path="/feaculty/users" element={<AllFeaculty />} />
          <Route path="/admin/courses/list" element={<CoursesList />} />
          <Route path="/courses/details/:id" element={<SingleCourse />} />
          <Route path="/admin/user/:id" element={<SingleUser />} />
          <Route path="/request-for-leave" element={<LeaveRequestForm />} />
          {/* <Route exact path="/students/record" element={<StudentsTable />} /> */}
          <Route exact path="*" element={<P404 />} />
          {/* End Admin Route */}
        </Routes>
      </AuthProvider>
    </div>
  );
}

export default App;
