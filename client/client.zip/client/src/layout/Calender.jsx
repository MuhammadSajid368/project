import React, { useState, useEffect, Fragment } from "react";
import FullCalendar from "@fullcalendar/react";
import dayGridPlugin from "@fullcalendar/daygrid";
import Sidebar from "../partials/Sidebar";
import Header from "../partials/Header";
import { useDispatch, useSelector } from 'react-redux';
import { toast } from "react-hot-toast";
import { addEvent } from "../redux/actions/eventAction";
import { sendNotificationToAllUsers } from "../redux/actions/sendNotification";
import "../css/event.css"


const Calendar = () => {
  const [title, setTitle] = useState("");
  const [date, setDate] = useState("");
  const [description, setDescription] = useState("");
  const [location, setLocation] = useState("");
  const [organizer, setOrganizer] = useState("");
  const [events, setEvents] = useState([]); // State variable to store events
  const dispatch = useDispatch();
  const [hoveredEvent, setHoveredEvent] = useState(null); // State variable to track hovered event
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleAddEvent = (e) => {
    e.preventDefault();
    // Check if both date and time are provided
    if (!date) {
      toast.error("Please select both date and time.");
      return;
    }
    const newEvent = { 
      title, 
      description, 
      date ,
      location, 
      organizer 
    };
    // Dispatch action to add event to the database
    dispatch(addEvent(newEvent))
      .then(() => {
        // Update events data with the new event
        setEvents([...events, newEvent]);
        // Show success message
        toast.success("Event Added Successfully!!!");
        dispatch(sendNotificationToAllUsers(newEvent));
        // Clear input fields after adding the event
        setTitle("");
        setDescription("");
        setDate("");
        setLocation("");
        setOrganizer("");
      })
      .catch((error) => {
        // Show error message if event addition fails
        toast.error(`Failed to add event: ${error.message}`);
      });
  };

  const handleEventMouseEnter = (info) => {
    // Set the hovered event when mouse enters an event
    setHoveredEvent(info.event);
  };

  const handleEventMouseLeave = () => {
    // Clear the hovered event when mouse leaves the event
    setHoveredEvent(null);
  };

  return (
    <Fragment>
      <div className="flex h-screen overflow-hidden">
        {/* Sidebar */}
        <Sidebar sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} />

        {/* Content area */}
        <div className="relative flex flex-col flex-1 overflow-y-auto overflow-x-hidden">
          {/*  Site header */}
          <Header sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} />

          <main>
            <div className="px-4 sm:px-6 lg:px-8 py-8 w-full max-w-9xl mx-auto">
              <div className="max-w-md mx-auto ">
                <FullCalendar
                  plugins={[dayGridPlugin]}
                  events={events} // Pass events data to FullCalendar component
                  eventMouseEnter={handleEventMouseEnter} // Callback for mouse enter event
                  eventMouseLeave={handleEventMouseLeave} // Callback for mouse leave event
                />
                <form onSubmit={handleAddEvent} className="mt-8 bg-white p-4">
                  <div className="grid grid-cols-1 gap-6">
                    <input
                      type="text"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      placeholder="Event Title"
                      required
                      className="input"
                    />
                    
                      <input
                        type="datetime-local"
                        value={date}
                        required
                        onChange={(e) => setDate(e.target.value)}
                        className="input"
                      />
                    <textarea
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      placeholder="Event Description"
                      required
                      className="input"
                    />
                    <input
                      type="text"
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                      placeholder="Event Location"
                      required
                      className="input"
                    />
                    <input
                      type="text"
                      value={organizer}
                      onChange={(e) => setOrganizer(e.target.value)}
                      placeholder="Event Organizer"
                      required
                      className="input"
                    />
                    <button
                      type="submit"
                      className="btn bg-blue-500 text-white hover:bg-blue-600"
                    >
                      Add Event
                    </button>
                  </div>
                </form>
                {/* Display title and date/time of hovered event */}
                {hoveredEvent && (
                  <div className="absolute top-0 left-0 bg-white shadow p-2">
                    <p>Title: {hoveredEvent.title}</p>
                    <p>Date/Time: {hoveredEvent.start.toLocaleString()}</p>
                  </div>
                )}
              </div>
            </div>
          </main>
        </div>
      </div>
    </Fragment>
  );
};

export default Calendar;
