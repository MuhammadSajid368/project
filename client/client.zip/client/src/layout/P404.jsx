import React from 'react'

const P404 = () => {
  return (
    <div>
      <p>Page Not Found!!!</p>
    </div>
  )
}

export default P404
