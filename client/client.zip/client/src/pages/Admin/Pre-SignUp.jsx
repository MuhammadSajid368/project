import axios from "axios";
import React, { useState } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import { MdNoAccounts } from "react-icons/md";

const PreSignUp = () => {
  const [fname, setFName] = useState("");
  const [lname, setLName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [loading, setLoading] = useState("");
  const [profilePic, setProfilePic] = useState("");
  const [gender, setGender] = useState("");

  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const toggleConfirmPasswordVisibility = () => {
    setShowConfirmPassword(!showConfirmPassword);
  };

  const navigate = useNavigate();
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      setLoading(true);
      const { data } = await axios.post(`/pre-signup`, { email, password });
      if (data?.error) {
        toast.error(data.error);
        setLoading(false);
      } else {
        toast.success("Please check your email to activate your account");
        setLoading(false);
        navigate("/");
      }
      console.log(data);
    } catch (err) {
      console.log(err);
      toast.error("Something went wrong. Try again!!");
      setLoading(false);
    }
  };

  return (
    <div>
      <div className="w-1/2 pl-7 rounded-xl mt-16 items-center m-auto">
        {loading ? "Loading ........." : ""}
        <form
          onSubmit={handleSubmit}
          className="bg-neutral-50 shadow-md rounded px-8 pt-4 pb-8 mb-4    mt-5"
        >
          <div>
            <p className="text-2xl font-bold mb-4 ml-auto mr-auto">
              Welcome Admin to create your Account!
            </p>
            <p className="mb-9 text-sm font-extralight">
              Hy Admin! Welcome to join as Admin . Kindly Enter a Verified Email
              Address to check that you are able to create Admin Account. Best
              of Luck!!
            </p>
            <div className="mb-4 flex flex-wrap">
              <div className="w-full md:w-1/2 mb-4 md:mb-0 pr-2">
                <label
                  htmlFor="name"
                  className="block text-gray-700 font-semibold mb-2"
                >
                  First Name
                </label>
                <input
                  type="text"
                  id="fname"
                  name="fname"
                  required
                  value={fname}
                  onChange={(e) => setFName(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 transition duration-150"
                  placeholder="First Name"
                />
              </div>
              <div className="w-full md:w-1/2 pl-2">
                <label
                  htmlFor="lastname"
                  className="block text-gray-700 font-semibold mb-2"
                >
                  Last Name
                </label>
                <input
                  type="text"
                  id="lname"
                  name="lname"
                  required
                  value={lname}
                  onChange={(e) => setLName(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 transition duration-150"
                  placeholder="Last Name"
                />
              </div>
            </div>

            <div className="mb-4">
              <label
                htmlFor="email"
                className="block text-gray-700 font-semibold mb-2"
              >
                Email:
              </label>
              <div className="relative">
                <input
                  type="email"
                  id="email"
                  required
                  name="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 transition duration-150 pr-10"
                  placeholder="Email Address*"
                />
              </div>
            </div>
            <div className="mb-4 flex flex-wrap">
              <div className="w-full md:w-1/2 mb-4 md:mb-0 pr-2">
                <label
                  htmlFor="password"
                  className="block text-gray-700 font-semibold mb-2"
                >
                  Password
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? "text" : "password"}
                    id="password"
                    required
                    name="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 transition duration-150 pr-10"
                    placeholder="Password"
                  />
                  <button
                    type="button"
                    className="absolute inset-y-0 right-0 px-4 py-2"
                    onClick={togglePasswordVisibility}
                  >
                    {showPassword ? "Hide" : "Show"}
                  </button>
                </div>
              </div>
              <div className="w-full md:w-1/2 mb-4 md:mb-0 pr-2">
                <label
                  htmlFor="confirmPassword"
                  className="block text-gray-700 font-semibold mb-2"
                >
                  Confirm Password
                </label>
                <div className="relative">
                  <input
                    type={showConfirmPassword ? "text" : "password"}
                    required
                    id="confirmPassword"
                    name="confirmPassword"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 transition duration-150 pr-10"
                    placeholder="Confirm Password"
                  />
                  <button
                    type="button"
                    className="absolute inset-y-0 right-0 px-4 py-2"
                    onClick={toggleConfirmPasswordVisibility}
                  >
                    {showConfirmPassword ? "Hide" : "Show"}
                  </button>
                </div>
              </div>
            </div>
            <div className="mb-4">
              <label
                htmlFor="profile_pic"
                className="block text-gray-700 font-semibold mb-2"
              >
                Profile Pic:
              </label>
              <div className="relative">
                <input
                  type="file" // Change input type to "file"
                  id="profile_pic" // Update id to match htmlFor in label
                  accept="image/*" // Specify accepted file types (in this case, images)
                  required
                  name="profile_pic"
                  value={profilePic}
                  onChange={(e) => setProfilePic(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 transition duration-150 pr-10"
                  placeholder="Upload Profile Picture"
                />
              </div>
            </div>
            <div className="mb-4 flex flex-wrap">
              <div className="w-full md:w-1/2 mb-4 md:mb-0 pr-2">
                <label
                  htmlFor="gender"
                  className="block text-gray-700 font-semibold mb-2"
                >
                  Gender
                </label>
                <select
                  id="gender"
                  name="gender"
                  required
                  value={gender}
                  onChange={(e) => setGender(e.target.value)}
                  className="block w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 transition duration-150"
                >
                  <option value="" disabled>
                    Select Gender
                  </option>
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                  <option value="custom">Custom</option>
                  <option value="prefer not to say">Prefer not to say</option>
                </select>
              </div>
            </div>
          </div>
          <button
            type="submit"
            disabled={loading}
            className="m-auto bg-lime-900 p-3 rounded-xl text-white"
          >
            {loading ? "Loading..." : "Create Account"}
          </button>
        </form>
      </div>
    </div>
  );
};

export default PreSignUp;
