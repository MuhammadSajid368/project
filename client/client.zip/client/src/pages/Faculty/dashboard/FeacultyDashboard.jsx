import React from 'react'
import Sidebar from './Sidebar'

const FeacultyDashboard = () => {
  return (
    <div className='w-full h-auto'>
        <div>
            <Sidebar />
        </div>
    </div>
  )
}

export default FeacultyDashboard