import React from 'react'

const CheckOutForm = () => {
  return (
    <div>CheckOutForm</div>
  )
}

export default CheckOutForm