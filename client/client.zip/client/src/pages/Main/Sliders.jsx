import React, { useState } from 'react'
import { BsChevronCompactLeft , BsChevronCompactRight } from 'react-icons/bs'
import { RxDotFilled } from 'react-icons/rx'

const Sliders = () => {
  const slides = [
    {
      url : "https://www.expat.com/images/upload/9/3/2/4/1698325737-university-in-germany-1-news_item_slider-t1698325737.jpg"
    },
    {
      url : "https://www.bankrate.com/2022/09/12184702/States-with-the-highest-and-lowest-student-loan-debt-in-2022.jpg?auto=webp&optimize=high&crop=16:9"
    },
    {
      url : "https://watermark.lovepik.com/photo/20211125/large/lovepik-xiamen-university-jian-nan-auditorium-playground-picture_501033525.jpg"
    },
    {
      url : "https://assets.teenvogue.com/photos/58d17622ca22480abd4d3e6e/16:9/w_1280,c_limit/german-slides-fb.jpg"
    },
    {
      url : "https://studyineurope.com.sg/storage/8172/home914-copia.jpg"
    }
  ]
  const [currentIndex  , setCurrentIndex] = useState(0)
  const prevSlider = () => {
    setCurrentIndex(currentIndex === 0 ? slides.length - 1 : currentIndex - 1)
  }
  const nextSlider = () => {
    setCurrentIndex(currentIndex ===  slides.length - 1 ? 0 : currentIndex + 1 )
  }

  const gotToSlide = (slideIndex ) => {
    setCurrentIndex(slideIndex)
  }
  return (
    <div className='max-w-[1400px] h-[630px] w-full m-auto py-16 px-4 relative group '>
      <div  style={{backgroundImage : `url(${slides[currentIndex].url})`}} className='w-full h-full rounded-sm bg-center bg-cover duration-500'></div>
      <div className='hidden group-hover:block absolute top-[50%] -translate-x-0 translate-y-[-50%] left-5 text-2xl rounded-full p-2 bg-black/20 text-white cursor-pointer '>
        <BsChevronCompactLeft onClick={prevSlider} size={30} />
      </div>
      <div className='hidden group-hover:block absolute top-[50%] -translate-x-0 translate-y-[-50%] right-5 text-2xl rounded-full p-2 bg-black/20 text-white cursor-pointer '>
        <BsChevronCompactRight onClick={nextSlider} size={30} />
      </div>
      <div className='flex top-4 justify-center py-2'>
      {slides.map((slide , slideIndex) => (
        <div key={slideIndex} onClick={() => gotToSlide(slideIndex)} className='text-2xl cursor-pointer'>
          <RxDotFilled />
        </div>
      ))}
      </div>
    </div>
  )
}

export default Sliders