import React from 'react'

const SuccessStories = () => {
  return (
    <div>SuccessStories</div>
  )
}

export default SuccessStories