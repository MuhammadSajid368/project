import React from 'react'
import Image from '../../images/images.jpeg'


const Third = () => {
    return (
       <div className="third">
        </div>
    )
}

export default Third