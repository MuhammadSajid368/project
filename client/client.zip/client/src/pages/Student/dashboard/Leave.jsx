import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Autocomplete from 'react-autocomplete';
import { FaGraduationCap, FaUsersViewfinder } from 'react-icons/fa6';
import Sidebar from './Sidebar';
import { useDispatch, useSelector } from 'react-redux';
import { fetchTeachers } from '../../../redux/actions/userAction';
import MetaData from '../../../layout/MetaData'
import { FaChalkboardTeacher } from 'react-icons/fa';

const Leave = () => {
    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(fetchTeachers());
    }, [dispatch]);

    const { loading, teachers, error } = useSelector((state) => state.teachers);
    const [leaveData, setLeaveData] = useState({
        sendto: '',
        leaveType: '',
        startDate: '',
        endDate: '',
        reason: ''
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setLeaveData(prevData => ({
            ...prevData,
            [name]: value
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            const response = await axios.post("/user/request-for-leave", leaveData);
            alert(response.data.message);

            // Reset form after successful submission
            setLeaveData({
                sendto: '',
                leaveType: '',
                startDate: '',
                endDate: '',
                reason: ''
            });
        } catch (error) {
            console.error("Error submitting leave:", error);
            alert("Error submitting leave. Please try again later.");
        }
    };

    return (
        <div className='flex'>
            <MetaData title={`Student Leave Request`} />
            <Sidebar />
            <div className='p-7'>
                <main>
                    <div className="px-4 sm:px-6 lg:px-8 py-8 w-full max-w-9xl mx-auto">
                        <form onSubmit={handleSubmit} className="pl-14 pr-14">
                            <p className="font-extrabold  text-2xl text-indigo-700">
                                Request For Leave
                            </p>
                            <div className="mb-3">
                                <label htmlFor="" className="block text-gray-700 font-semibold mb-2">Instructor:</label>
                                <div className="flex items-center">
                                    <i className="border p-2.5">
                                        <FaChalkboardTeacher className="text-xl" />
                                    </i>
                                    <select
                                        name="courseInstructor"
                                        value={leaveData.sendto}
                                        onChange={handleChange}
                                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 transition duration-150 pr-10"
                                    >
                                        <option value="">Instructor</option>
                                        {teachers
                                            ? teachers.map((teacher) => (
                                                <option key={teacher._id} value={teacher._id} className="p-4">
                                                    {teacher.first_name} {teacher.last_name}
                                                </option>
                                            )) :
                                            "No Teacher Found!!"
                                        }
                                    </select>

                                </div>
                            </div>
                            <div className="mb-3  mt-3">
                                <label htmlFor="leaveType" className="block text-gray-700 font-semibold mb-2">
                                    Leave Type :
                                </label>
                                <div className="flex items-center">
                                    <i className="border p-2.5">
                                        <FaUsersViewfinder className="text-xl" />
                                    </i>
                                    <input type="text" name="leaveType" id="leaveType" />
                                </div>
                            </div>
                            <div className="mb-3  mt-3">
                                <label htmlFor="startDate" className="block text-gray-700 font-semibold mb-2">
                                    Starting From :
                                </label>
                                <div className="flex items-center">
                                    <i className="border p-2.5">
                                        <FaUsersViewfinder className="text-xl" />
                                    </i>
                                    <input type="date" name="startDate" id="startDate" />
                                </div>
                            </div>
                            <div className="mb-3  mt-3">
                                <label htmlFor="endDate" className="block text-gray-700 font-semibold mb-2">
                                    Ending From :
                                </label>
                                <div className="flex items-center">
                                    <i className="border p-2.5">
                                        <FaUsersViewfinder className="text-xl" />
                                    </i>
                                    <input type="date" name="endDate" id="endDate" />
                                </div>
                            </div>
                            <div className="mb-3  mt-3">
                                <label htmlFor="reason" className="block text-gray-700 font-semibold mb-2">
                                    Reason :
                                </label>
                                <div className="flex items-center">
                                    <i className="border p-2.5">
                                        <FaUsersViewfinder className="text-xl" />
                                    </i>
                                    <input type="text" name="reason" id="reason" />
                                </div>
                            </div>
                            <div className="justify-center items-center m-auto mt-6 w-full">
                                <button type="submit" className="p-4 text-center bg-indigo-700 rounded-2xl text-white">Add Course</button>
                            </div>

                        </form>
                    </div>
                </main>
            </div>
        </div>
    );
};

export default Leave;
