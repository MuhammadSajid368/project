import React from 'react'
import Sidebar from './Sidebar'
import MetaData from '../../../layout/MetaData'

const StudentDashboard = () => {
  return (
    <div className='w-full h-auto'>
      <MetaData title={`Student Dashboard`} />
        <div>
            <Sidebar />
        </div>
    </div>
  )
}

export default StudentDashboard