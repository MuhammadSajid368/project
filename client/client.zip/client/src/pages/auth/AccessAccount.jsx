import React, { useEffect } from 'react'
import { useAuth } from '../../context/auth'
import { useNavigate, useParams } from 'react-router-dom';
import axios from 'axios';
import {toast} from "react-hot-toast"


const AccessAccount = () => {
    /*  context */
    const [auth , setAuth] = useAuth();

    /*  useParams Hook */
    const {token} = useParams();
    const navigate = useNavigate();

    /*  useEffect Hooks */
    useEffect(() => {
    if (token) requestForAccessAccount
    } , [token])
const requestForAccessAccount = async ()=> {
  try {
    const {data} = await axios.post("/reset-password/:resetCode" , {resetCode :  token})
    if (data?.error) { 
      toast.error(data.error)
    }
    else{
        /*  save in local storage */
        localStorage.setItem("auth" , JSON.stringify(data))

        /*  save in context */
        setAuth(data)
        toast.success("Please update your password in Profile page")
        navigate("/")
    }
  } catch (error) {
    console.log(error)
    toast.error("password Request failed!.... Try Again.")
  }
} 
  return (
    <div>
      <div>
        <p>Please Wait........</p>
        <br /><br /><br /><br />
        <p>Loading</p>
      </div>
    </div>
  )
}

export default AccessAccount
