import React from 'react'
import Sidebar from './Sidebar'

const GuestDashboard = () => {
  return (
    <div className='w-full h-auto'>
        <div>
            <Sidebar />
        </div>
    </div>
  )
}

export default GuestDashboard