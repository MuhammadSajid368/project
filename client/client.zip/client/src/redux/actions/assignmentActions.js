
export const updateAssignmentForm = (formData) => ({
    type: 'UPDATE_ASSIGNMENT_FORM',
    payload: formData
  });
  
  export const submitAssignmentForm = (formData) => ({
    type: 'SUBMIT_ASSIGNMENT_FORM',
    payload: formData
  });
  