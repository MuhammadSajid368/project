
import axios from 'axios'
import { ADD_EVENT_FAILURE, ADD_EVENT_REQUEST, ADD_EVENT_SUCCESS } from '../constant/allConstants'



export const addEvent = (newEvent) => async (dispatch) => {
    try {
      dispatch({ type: ADD_EVENT_REQUEST });
      
      // Make API request to add the event
      const { data } = await axios.post(`http://localhost:8080/api/v1/create`, newEvent);
  
      dispatch({
        type: ADD_EVENT_SUCCESS,
        payload: data,
      });
    } catch (error) {
      dispatch({
        type: ADD_EVENT_FAILURE,
        payload: error.response.data.message || 'Something went wrong',
      });
    }
  };

// export const fetchUsers = (currentPage =  1) => async (dispatch) => {

//     try{
//         dispatch({ type :  ALL_USERS_REQUEST})
//         const {data} = await axios.get(`http://localhost:8080/api/v1/admin/all/users/?page=${currentPage}`)
    
//         dispatch({
//             type : ALL_USERS_SUCCESS ,
//             payload : data ,
//         })
//         console.log(data)
//     } catch(error){
//         dispatch({
//             type : ALL_USERS_FAILURE ,
//             payload : error.response.data.message
//         })
//     }
// }

// export const userDetails = (id) => async (dispatch) => {
//     try {
//         dispatch({type : USER_DETAILS_REQUEST})
//         const {data} = await axios.get(`http://localhost:8080/api/v1/admin/user/${id}`)
//         dispatch({
//             type : USER_DETAILS_SUCCESS ,
//             payload : data.user
//         })
//     } catch (error) {
//         dispatch({
//             type : USER_DETAILS_FAILURE,
//             payload : error.response.data.message
//         })
//     }
// }

export const clearErrors = () => async(dispatch) => {
    dispatch({
        type : CLEAR_ERRORS
    })
}