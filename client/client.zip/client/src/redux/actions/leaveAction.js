import { CLEAR_ERRORS, POST_LEAVE_FAILURE, POST_LEAVE_REQUEST, POST_LEAVE_SUCCESS } from "../constant/allConstants";

export const postLeaveRequest = (leaveData) => async (dispatch) => {
    try {
      dispatch({ type: POST_LEAVE_REQUEST });
      const res = await axios.post('http://localhost:8080/api/v1/user/request-for-leave', leaveData);
      dispatch({
        type: POST_LEAVE_SUCCESS,
        payload: res.data
      });
    } catch (error) {
      dispatch({
        type: POST_LEAVE_FAILURE,
        payload: error.response.data.error
      });
    }
  };