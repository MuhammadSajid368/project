
export const updateQuizForm = (formData) => ({
    type: 'UPDATE_QUIZ_FORM',
    payload: formData
  });
  
  export const submitQuizForm = (formData) => ({
    type: 'SUBMIT_QUIZ_FORM',
    data : payload.data.quiz
  });
  