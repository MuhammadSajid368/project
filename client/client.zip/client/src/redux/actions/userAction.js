
import axios from 'axios'
import { ALL_USERS_FAILURE, ALL_USERS_REQUEST, ALL_USERS_SUCCESS, CLEAR_ERRORS, FETCH_FEACULTY_FAILURE, FETCH_FEACULTY_REQUEST, FETCH_FEACULTY_SUCCESS, FETCH_STUDENTS_FAILURE, FETCH_STUDENTS_REQUEST, FETCH_STUDENTS_SUCCESS, FETCH_TEACHERS_FAILURE, FETCH_TEACHERS_REQUEST, FETCH_TEACHERS_SUCCESS, USER_DETAILS_FAILURE, USER_DETAILS_REQUEST, USER_DETAILS_SUCCESS } from '../constant/allConstants'


export const fetchUsers = (currentPage =  1) => async (dispatch) => {

    try{
        dispatch({ type :  ALL_USERS_REQUEST})
        const {data} = await axios.get(`http://localhost:8080/api/v1/admin/all/users`)
    
        dispatch({
            type : ALL_USERS_SUCCESS ,
            payload : data ,
        })
        console.log(data)
    } catch(error){
        dispatch({
            type : ALL_USERS_FAILURE ,
            payload : error.response.data.message
        })
    }
}

export const userDetails = (id) => async (dispatch) => {
    try {
        dispatch({type : USER_DETAILS_REQUEST})
        const {data} = await axios.get(`http://localhost:8080/api/v1/admin/user/${id}`)
        dispatch({
            type : USER_DETAILS_SUCCESS ,
            payload : data.user
        })
    } catch (error) {
        dispatch({
            type : USER_DETAILS_FAILURE,
            payload : error.response.data.message
        })
    }
}

export const clearErrors = () => async(dispatch) => {
    dispatch({
        type : CLEAR_ERRORS
    })
}

export const fetchStudents = () => async (dispatch) => {
    dispatch({ type: FETCH_STUDENTS_REQUEST });
    try {
        const response = await axios.get('/all/students');
        dispatch({
            type: FETCH_STUDENTS_SUCCESS,
            payload: response.data
        });
    } catch (error) {
        dispatch({
            type: FETCH_STUDENTS_FAILURE,
            payload: error.message
        });
    }
};

export const fetchTeachers = () => async (dispatch) => {
    dispatch({ type: FETCH_TEACHERS_REQUEST });
    try {
        const response = await axios.get('/all/teachers');
        dispatch({
            type: FETCH_TEACHERS_SUCCESS,
            payload: response.data
        });
    } catch (error) {
        dispatch({
            type: FETCH_TEACHERS_FAILURE,
            payload: error.message
        });
    }
};


export const fetchFeaculty = () => async (dispatch) => {
    dispatch({ type: FETCH_FEACULTY_REQUEST });
    try {
        const response = await axios.get('/all/staff');
        dispatch({
            type: FETCH_FEACULTY_SUCCESS,
            payload: response.data
        });
    } catch (error) {
        dispatch({
            type: FETCH_FEACULTY_FAILURE,
            payload: error.message
        });
    }
};