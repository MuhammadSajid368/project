import { ADD_EVENT_FAILURE, ADD_EVENT_REQUEST, ADD_EVENT_SUCCESS, CLEAR_ERRORS } from "../constant/allConstants";

  const initialState = {
    events: [],
    loading: false,
    error: null,
    event: {},
  };
  
  export const eventReducer = (state = initialState, action) => {
    switch (action.type) {
      case ADD_EVENT_REQUEST:
        return {
          loading: true,
        };
      case ADD_EVENT_SUCCESS:
        return {
          loading: false,
          events : {},
          error: null,
        };
      case ADD_EVENT_FAILURE:
        return {
          loading: false,
          error: action.payload,
        };
      case CLEAR_ERRORS:
        return {
          ...state,
          error: null,
        };
      default:
        return state;
    }
  };
  
  // export const EventsDetails = (state = initialState, action) => {
  //   switch (action.type) {
  //     case USER_DETAILS_REQUEST:
  //       return {
  //         ...state,
  //         loading: true,
  //       };
  //     case USER_DETAILS_SUCCESS:
  //       return {
  //         loading: false,
  //         user: action.payload,
  //       };
  //     case USER_DETAILS_FAILURE:
  //       return {
  //         ...state,
  //         loading: false,
  //         error: action.payload,
  //       };
  //     case CLEAR_ERRORS:
  //       return {
  //         ...state,
  //         error: null,
  //       };
  //     default:
  //       return state;
  //   }
  // };
  